SAMPLE PREDICTIONS
Description: These sample predictions are all based off of actual SDM predictions, but are not actual SDM predictions themselves.

Sample_predictions_1
Description: A .csv file containing 33,666 rows of data, 11,994 of which have non-NA predictions. The columns are: longitude and latitude coordinates of the centroids of prediction cells, four columns with prediction values, one column with weights randomly generated number from 0 to 1), and one column wih prediction indicies. The resolution is 0.1, meaning each centroid point is 0.1 degrees from its neighbors, and the geometry is a rectangle spanning 30 degrees N to 48 degrees N and 134 degrees E to 115 degrees E (although the longitude coordinates are in the range 0 - 360).
Intended use: Original SDM imported in 'Import Model Predictions' tab.

Sample_predictions_2
Description: A .csv file containing 6237 rows of data, 4059 of which have non-NA predictions. The columns are: longitude and latitude coordinaates
Intended use: Original SDM imported in 'Import Model Predictions' tab.

Sample_predictions_3
Description: A .csv file of predictions that span the antimeridian. These predictions are the same as Sample_predictions_1 shifted west.
Intended use: Original SDM imported in 'Import Model Predictions' tab.

Sample_predictions_4
Description: A file geodatabase feature class of predictions along the U.S. West Coast. The geometry of these predictions is invalid and thus is fixed when importing the preictions into the GUI.
Intended use: Original SDM imported in 'Import Model Predictions' tab.

Sample_predictions_5
Description: A raster of predictions along the U.S. West Coast.
Intended use: Original SDM imported in 'Import Model Predictions' tab.

Sample_predictions_6
Description: A shapefile of predictions that span the antimeridian and are centered around the Hawaiian Islands.
Intended use: Original SDM imported in 'Import Model Predictions' tab.




OTHER OBJECTS

NorCal_poly.csv: A .csv file with coordinates for a rectangle spanning 40 degrees north to 50 degrees north and 124 degrees east to 118 degrees east. 
Intended use: Study area polygon or a weight polygon.

SoCal_bight.csv: A .csv file with coordinates for a rectangle spanning 32 degrees north to 35 degrees north and 123 degrees east to 117 degrees east. 
Intended use: Study area polygon or a weight polygon.

Validation_data.csv: A.csv file with randomly generated validation data points within the bounding box "-130.9, 30.0, -117.2, 48.0". There are several columns, including a 'sight' column which contain sample presence/absence data (1's and 0's signifying presence/absence, respectively) and a 'count' column which contains sample count data (presence/absence matches with 'sight' column).
Intended use: Validation data

